﻿#pragma once

#include <Framework/Object/Component/Script.h>

namespace game
{
    class $safeitemname$ :
        public engine::Script<$safeitemname$>
    {
        REGISTER_SCRIPT($safeitemname$, Script)

    public:
        //void Awake() override;
        //void Start() override;
        //void Update() override;

    public:
        void OnGui() override;
        void Save(engine::json& j) const override;
        void Load(const engine::json& j) override;
    };
}