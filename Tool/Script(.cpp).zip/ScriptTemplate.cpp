﻿#include "GamePCH.h"
#include "$safeitemname$.h"

namespace game
{
    void $safeitemname$::OnGui()
    {
    }

    void $safeitemname$::Save(engine::json& j) const
    {
        Object::Save(j);
    }

    void $safeitemname$::Load(const engine::json& j)
    {
        Object::Load(j);
    }

    std::string $safeitemname$::GetType() const
    {
        return "$safeitemname$";
    }
}